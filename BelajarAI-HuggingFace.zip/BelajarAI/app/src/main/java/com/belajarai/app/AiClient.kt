package com.belajarai.app

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/** Klien Hugging Face Inference Providers (OpenAI-compatible API). */
object AiClient {
    private const val URL = "https://router.huggingface.co/v1/chat/completions"
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(150, TimeUnit.SECONDS)
        .build()
    private val main = Handler(Looper.getMainLooper())

    fun call(prefs: Prefs, system: String, userText: String, image: Bitmap?, onDone: (Result<String>) -> Unit) {
        val key = prefs.apiKey
        val model = prefs.model
        Thread {
            val r = runCatching { blocking(key, model, system, userText, image) }
            main.post { onDone(r) }
        }.start()
    }

    private fun blocking(key: String, model: String, system: String, userText: String, image: Bitmap?): String {
        require(key.isNotBlank()) { "Hugging Face token belum diisi. Buka BelajarAI > Koneksi AI." }
        val userContent = JSONArray()
        userContent.put(JSONObject().put("type", "text").put("text", userText))
        if (image != null) {
            userContent.put(
                JSONObject().put("type", "image_url").put(
                    "image_url", JSONObject().put("url", "data:image/jpeg;base64,${toBase64(image)}")
                )
            )
        }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", userContent))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4000)
            .put("messages", messages)
        val req = Request.Builder().url(URL)
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { resp ->
            val s = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching {
                    val json = JSONObject(s)
                    json.optJSONObject("error")?.optString("message")
                        ?: json.optString("message", s.take(240))
                }.getOrDefault(s.take(240))
                error("Hugging Face API ${resp.code}: $msg")
            }
            val json = JSONObject(s)
            val choices = json.optJSONArray("choices") ?: error("Respons Hugging Face tidak memiliki choices.")
            val message = choices.getJSONObject(0).getJSONObject("message")
            val content = message.opt("content")
            return when (content) {
                is String -> content
                is JSONArray -> buildString {
                    for (i in 0 until content.length()) {
                        val item = content.optJSONObject(i) ?: continue
                        if (item.optString("type") == "text") append(item.optString("text"))
                    }
                }
                else -> error("Respons teks AI tidak terbaca.")
            }
        }
    }

    private fun toBase64(src: Bitmap): String {
        val max = 1600f
        val scale = minOf(1f, max / maxOf(src.width, src.height))
        val b = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun extractJson(text: String): JSONObject {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        require(s >= 0 && e > s) { "Format jawaban AI tidak terbaca." }
        return JSONObject(text.substring(s, e + 1))
    }
}
