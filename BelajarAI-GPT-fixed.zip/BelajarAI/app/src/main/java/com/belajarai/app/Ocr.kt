package com.belajarai.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** OCR on-device memakai Google ML Kit. Callback di main thread. */
object Ocr {
    fun read(bmp: Bitmap, cb: (Result<String>) -> Unit) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { cb(Result.success(it.text)) }
            .addOnFailureListener { cb(Result.failure(it)) }
    }
}
