package com.belajarai.app

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }
        c.addView(tv("Riwayat Latihan", 24f, C.BLUE, true))
        val list = HistoryStore.all(this)
        if (list.isEmpty()) c.addV(tv("Belum ada riwayat. Selesaikan satu simulasi CBT dulu.", 13f, C.MUTED), 10)
        else {
            val avg = list.map { it.score }.average().toInt()
            c.addV(tv("${list.size} latihan • rata-rata nilai $avg", 13f, C.MUTED), 4)
        }
        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id"))
        list.forEach {
            val k = card()
            k.addView(tv("${it.subject} • ${it.difficulty}", 14f, C.TEXT, true))
            k.addV(tv(fmt.format(Date(it.time)), 11f, C.MUTED), 2)
            k.addV(tv("Nilai ${it.score}  (benar ${it.correct}/${it.total})", 15f, if (it.score >= it.target) C.GREEN else C.ORANGE, true), 4)
            k.addV(tv("Target nilai ${it.target}: " + if (it.score >= it.target) "tercapai" else "belum tercapai", 12f, C.MUTED), 2)
            c.addV(k, 8)
        }
        if (list.isNotEmpty()) c.addV(btn("Hapus riwayat", false) { HistoryStore.clear(this); render() }, 16)
        c.addV(btn("Kembali", false) { finish() }, 8)
        setContentView(ScrollView(this).apply { addView(c); setBackgroundColor(C.WHITE) })
    }
}
