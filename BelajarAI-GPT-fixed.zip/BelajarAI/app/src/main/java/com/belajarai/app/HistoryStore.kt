package com.belajarai.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Record(val time: Long, val subject: String, val difficulty: String, val total: Int, val correct: Int, val score: Int, val target: Int)

object HistoryStore {
    private fun sp(c: Context) = c.getSharedPreferences("belajarai_history", Context.MODE_PRIVATE)

    fun add(c: Context, r: Record) {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        arr.put(JSONObject().put("time", r.time).put("subject", r.subject).put("difficulty", r.difficulty)
            .put("total", r.total).put("correct", r.correct).put("score", r.score).put("target", r.target))
        sp(c).edit().putString("list", arr.toString()).apply()
    }

    fun all(c: Context): List<Record> {
        val arr = JSONArray(sp(c).getString("list", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Record(o.getLong("time"), o.getString("subject"), o.getString("difficulty"), o.getInt("total"), o.getInt("correct"), o.getInt("score"), o.getInt("target"))
        }.reversed()
    }

    fun clear(c: Context) = sp(c).edit().remove("list").apply()
}
