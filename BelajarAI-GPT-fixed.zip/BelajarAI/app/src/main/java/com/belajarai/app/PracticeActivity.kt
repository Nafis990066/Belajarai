package com.belajarai.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.*
import kotlin.math.min

/** Simulasi CBT: soal dibuat AI, dinilai otomatis, ada pembahasan & riwayat. */
class PracticeActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var frame: FrameLayout
    private var questions = listOf<Item>()
    private val chosen = HashMap<Int, String>()
    private var index = 0
    private var timer: CountDownTimer? = null
    private var tvTimer: TextView? = null
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        frame = FrameLayout(this).apply { setBackgroundColor(C.WHITE) }
        setContentView(frame)
        showSetup()
    }

    private fun page(content: LinearLayout) {
        content.setPadding(dp(18), dp(18), dp(18), dp(24))
        frame.removeAllViews()
        frame.addView(ScrollView(this).apply { addView(content) })
    }

    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    // ------------------------------------------------------------ setup
    private fun showSetup() {
        val c = col()
        c.addView(tv("Simulasi CBT", 24f, C.BLUE, true))
        val s = card()
        s.addView(tv("Mata pelajaran: ${prefs.subject}", 14f))
        s.addV(tv("Kesulitan: ${prefs.difficulty}", 14f), 4)
        s.addV(tv("Jumlah soal: ${prefs.practiceCount}", 14f), 4)
        s.addV(tv("Target: ${prefs.targetCorrect} benar • nilai ${prefs.targetScore}", 14f), 4)
        s.addV(tv("Waktu: ${prefs.practiceCount * 90 / 60} menit", 14f), 4)
        s.addV(tv("Ubah di menu Pengaturan Soal pada halaman utama.", 11f, C.MUTED), 6)
        c.addV(s, 12)
        if (prefs.apiKey.isBlank()) c.addV(tv("API key belum diisi (halaman utama).", 12f, C.RED, true), 8)
        c.addV(btn("Mulai") { generate() }, 12)
        c.addV(btn("Kembali", false) { finish() }, 8)
        page(c)
    }

    private fun showLoading(msg: String) {
        val c = col()
        c.addView(tv("Menyiapkan soal…", 20f, C.BLUE, true))
        c.addV(tv(msg, 13f, C.MUTED), 8)
        c.addV(ProgressBar(this), 16)
        page(c)
    }

    private fun showError(msg: String) {
        val c = col()
        c.addView(tv("Gagal membuat soal", 20f, C.RED, true))
        c.addV(tv(msg, 13f), 8)
        c.addV(btn("Coba lagi") { generate() }, 12)
        c.addV(btn("Kembali", false) { showSetup() }, 8)
        page(c)
    }

    // ------------------------------------------------------------ generate
    private fun generate() {
        if (prefs.apiKey.isBlank()) { toast("Isi API key di halaman utama."); return }
        showLoading("AI sedang menyusun ${prefs.practiceCount} soal…")
        gen(prefs.practiceCount, mutableListOf())
    }

    private fun gen(remaining: Int, acc: MutableList<Item>) {
        val k = min(10, remaining)
        val avoid = acc.takeLast(15).joinToString("; ") { it.question.take(50) }
        val user = "Buat soal sekarang." + if (avoid.isNotEmpty()) " Hindari topik yang sama dengan: $avoid" else ""
        AiClient.call(prefs, Prompts.generate(prefs.subject, prefs.difficulty, k), user, null) { r ->
            r.onFailure { showError(it.message ?: "Terjadi kesalahan."); return@call }
            val parsed = runCatching { Parser.items(AiClient.extractJson(r.getOrThrow())).filter { it.options.size >= 2 && it.answer.isNotBlank() } }
                .getOrElse { showError("Format jawaban AI tidak terbaca."); return@call }
            acc.addAll(parsed.take(k))
            showLoading("Soal tersusun: ${acc.size}/${prefs.practiceCount}")
            when {
                acc.size >= prefs.practiceCount -> startQuiz(acc)
                parsed.isEmpty() -> if (acc.isEmpty()) showError("AI tidak mengembalikan soal.") else startQuiz(acc)
                else -> gen(prefs.practiceCount - acc.size, acc)
            }
        }
    }

    // ------------------------------------------------------------ quiz
    private fun startQuiz(list: List<Item>) {
        questions = list; chosen.clear(); index = 0; finished = false
        timer?.cancel()
        timer = object : CountDownTimer(list.size * 90_000L, 1000) {
            override fun onTick(ms: Long) { tvTimer?.text = "⏱ %02d:%02d".format(ms / 60000, (ms / 1000) % 60) }
            override fun onFinish() { if (!finished) { toast("Waktu habis."); submit() } }
        }.start()
        showQuestion()
    }

    private fun showQuestion() {
        val q = questions[index]
        val c = col()
        val top = LinearLayout(this)
        top.addView(tv("Soal ${index + 1}/${questions.size}", 14f, C.BLUE, true), LinearLayout.LayoutParams(0, -2, 1f))
        tvTimer = tv("", 14f, C.MUTED, true); top.addView(tvTimer)
        c.addView(top)
        c.addV(tv("Terjawab: ${chosen.size}/${questions.size}", 11f, C.MUTED), 2)
        c.addV(tv(q.question, 16f), 12)
        q.options.forEach { (k, v) ->
            val sel = chosen[index] == k
            val o = tv("$k.  $v", 14f, if (sel) C.WHITE else C.TEXT, sel).apply {
                background = bg(if (sel) C.BLUE else C.WHITE, 12, if (sel) C.BLUE else C.LINE, 1)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { chosen[index] = k; showQuestion() }
            }
            c.addV(o, 8)
        }
        val nav = LinearLayout(this)
        nav.addView(btn("‹ Sebelumnya", false) { if (index > 0) { index--; showQuestion() } }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        nav.addView(btn("Berikutnya ›", false) { if (index < questions.size - 1) { index++; showQuestion() } }, LinearLayout.LayoutParams(0, -2, 1f))
        c.addV(nav, 16)
        c.addV(btn("Selesai & Nilai") {
            val unanswered = questions.size - chosen.size
            AlertDialog.Builder(this).setTitle("Selesaikan latihan?")
                .setMessage(if (unanswered > 0) "Masih ada $unanswered soal belum dijawab." else "Semua soal sudah dijawab.")
                .setPositiveButton("Selesai") { _, _ -> submit() }.setNegativeButton("Lanjut mengerjakan", null).show()
        }, 12)
        page(c)
    }

    // ------------------------------------------------------------ result
    private fun submit() {
        if (finished) return
        finished = true; timer?.cancel()
        val total = questions.size
        val correct = questions.indices.count { chosen[it].equals(questions[it].answer.take(1), true) || chosen[it].equals(questions[it].answer, true) }
        val score = if (total == 0) 0 else Math.round(correct * 100f / total)
        HistoryStore.add(this, Record(System.currentTimeMillis(), prefs.subject, prefs.difficulty, total, correct, score, prefs.targetScore))

        val c = col()
        c.addView(tv("Hasil Latihan", 24f, C.BLUE, true))
        val s = card()
        s.addView(tv("Nilai: $score", 34f, if (score >= prefs.targetScore) C.GREEN else C.ORANGE, true))
        s.addV(tv("Benar $correct • Salah ${total - correct - (total - chosen.size)} • Kosong ${total - chosen.size}", 14f), 4)
        val goalC = correct >= prefs.targetCorrect
        val goalS = score >= prefs.targetScore
        s.addV(tv("Target ${prefs.targetCorrect} benar: " + if (goalC) "tercapai ✓" else "belum (kurang ${prefs.targetCorrect - correct})", 13f, if (goalC) C.GREEN else C.ORANGE, true), 6)
        s.addV(tv("Target nilai ${prefs.targetScore}: " + if (goalS) "tercapai ✓" else "belum tercapai", 13f, if (goalS) C.GREEN else C.ORANGE, true), 2)
        c.addV(s, 12)

        c.addV(tv("Pembahasan", 18f, C.TEXT, true), 18)
        questions.forEachIndexed { i, q ->
            val ans = chosen[i]
            val ok = ans != null && (ans.equals(q.answer.take(1), true) || ans.equals(q.answer, true))
            val card = card()
            card.addView(tv("${i + 1}. " + if (ok) "Benar ✓" else if (ans == null) "Tidak dijawab" else "Salah ✗", 13f, if (ok) C.GREEN else C.RED, true))
            card.addV(tv(q.question, 13f), 4)
            card.addV(tv("Jawabanmu: ${ans ?: "-"}   •   Kunci: ${q.answer}", 12f, C.BLUE, true), 4)
            if (q.explanation.isNotBlank()) card.addV(tv(q.explanation, 12f, C.MUTED), 4)
            c.addV(card, 8)
        }
        c.addV(btn("Latihan lagi") { generate() }, 16)
        c.addV(btn("Riwayat", false) { startActivity(android.content.Intent(this, HistoryActivity::class.java)) }, 8)
        c.addV(btn("Selesai", false) { finish() }, 8)
        page(c)
    }

    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
