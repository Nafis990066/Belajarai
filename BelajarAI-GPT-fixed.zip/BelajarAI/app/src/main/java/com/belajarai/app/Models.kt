package com.belajarai.app

import org.json.JSONObject

data class Item(
    val number: String,
    val question: String,
    val options: Map<String, String>,
    val answer: String,
    val explanation: String,
    val confidence: Int,
    val needsClarification: Boolean,
    val clarification: String
)

object Parser {
    fun items(o: JSONObject): List<Item> {
        val arr = o.optJSONArray("items") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val x = arr.getJSONObject(i)
            val opts = LinkedHashMap<String, String>()
            x.optJSONObject("options")?.let { op -> op.keys().forEach { k -> opts[k.uppercase()] = op.optString(k) } }
            Item(
                x.optString("number", "${i + 1}"),
                x.optString("question"),
                opts,
                x.optString("answer").trim(),
                x.optString("explanation"),
                x.optInt("confidence", 0).coerceIn(0, 100),
                x.optBoolean("needs_clarification", false),
                x.optString("clarification")
            )
        }
    }
}
