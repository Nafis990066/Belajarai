package com.belajarai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

/**
 * Floating bubble + panel AI + tangkap layar (MediaProjection) + OCR + AI.
 * Hanya membaca layar atas izin pengguna. Layar yang diproteksi (FLAG_SECURE) tampil hitam
 * dan TIDAK dicoba dilewati.
 */
class FloatingService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CH = "belajarai"
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var latest: Image? = null
    private var onFrame: (() -> Unit)? = null

    private var uiBuilt = false
    private lateinit var bubble: TextView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var tvStatus: TextView
    private lateinit var tvChip: TextView
    private lateinit var results: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var etInput: EditText
    private var panelShown = false
    private var expanded = false
    private var busy = false
    private var lastOcr = ""
    private var lastBmp: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        if (projection == null && data != null) {
            try {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mpm.getMediaProjection(code, data)
                projection!!.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { main.post { toast("Izin tangkap layar berakhir."); stopSelf() } }
                }, main)
                setupCapture()
            } catch (e: Exception) {
                toast("Gagal memulai tangkap layar: ${e.message}")
                stopSelf(); return START_NOT_STICKY
            }
        }
        if (!uiBuilt) { buildUi(); uiBuilt = true }
        running = true
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "BelajarAI", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("BelajarAI aktif")
            .setContentText("Tekan bubble AI untuk membuka asisten.")
            .setSmallIcon(R.drawable.ic_launcher)
            .addAction(Notification.Action.Builder(null, "Hentikan", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    // ---------------------------------------------------------------- capture
    private fun setupCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        latest?.close(); latest = null
        reader?.close()
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            latest?.close()
            latest = img
            val cb = onFrame; onFrame = null; cb?.invoke()
        }, main)
        reader = r
        if (vd == null) {
            vd = projection!!.createVirtualDisplay(
                "belajarai", dm.widthPixels, dm.heightPixels, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
            )
        } else {
            vd!!.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi)
            vd!!.surface = r.surface
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * img.width
        val buf = p.buffer; buf.rewind()
        val bmp = Bitmap.createBitmap(img.width + rowPad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(buf)
        return Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    /** Sembunyikan overlay sebentar supaya tidak ikut terfoto, lalu ambil frame terbaru. */
    private fun capture(cb: (Bitmap?) -> Unit) {
        bubble.visibility = View.INVISIBLE
        if (panelShown) panel.visibility = View.INVISIBLE
        var done = false
        val finish = {
            if (!done) {
                done = true
                onFrame = null
                val bmp = latest?.let { runCatching { toBitmap(it) }.getOrNull() }
                bubble.visibility = View.VISIBLE
                if (panelShown) panel.visibility = View.VISIBLE
                cb(bmp)
            }
        }
        main.postDelayed({ if (!done) onFrame = { finish() } }, 250)
        main.postDelayed({ finish() }, 1300)
    }

    private fun looksBlack(b: Bitmap): Boolean {
        var lit = 0
        val sx = b.width / 20; val sy = b.height / 20
        for (i in 0 until 20) for (j in 0 until 20) {
            val p = b.getPixel(i * sx + sx / 2, j * sy + sy / 2)
            if (Color.red(p) + Color.green(p) + Color.blue(p) > 30) lit++
        }
        return lit < 4
    }

    // ---------------------------------------------------------------- flow
    private fun scan() {
        if (busy) return
        busy = true
        setStatus("Mengambil layar…")
        capture { bmp ->
            if (bmp == null) { fail("Gagal mengambil layar. Coba lagi."); return@capture }
            if (looksBlack(bmp)) {
                fail("Layar tampak hitam/terlindungi. BelajarAI tidak membaca layar yang diproteksi aplikasi lain.")
                return@capture
            }
            lastBmp = bmp
            setStatus("Membaca teks (OCR)…")
            Ocr.read(bmp) { r ->
                val text = r.getOrDefault("")
                lastOcr = text
                if (text.isBlank() && !prefs.sendImage) { fail("Tidak ada teks yang terbaca di layar."); return@read }
                analyze(text, "", if (prefs.sendImage) bmp else null)
            }
        }
    }

    private fun analyze(ocr: String, extra: String, bmp: Bitmap?) {
        busy = true
        setStatus("AI menganalisis soal…")
        val limit = if (prefs.processCount == 0) "semua" else prefs.processCount.toString()
        val sb = StringBuilder()
        sb.append("Mata pelajaran: ${prefs.subject}\nBatas jumlah soal: $limit\n")
        if (ocr.isNotBlank()) sb.append("\nTeks hasil OCR layar:\n$ocr\n")
        if (extra.isNotBlank()) sb.append("\nKeterangan/pertanyaan tambahan dari pengguna:\n$extra\n")
        AiClient.call(prefs, Prompts.solve(prefs), sb.toString(), bmp) { r ->
            busy = false
            r.onSuccess { text ->
                runCatching { Parser.items(AiClient.extractJson(text)) }
                    .onSuccess { items ->
                        val shown = if (prefs.processCount > 0) items.take(prefs.processCount) else items
                        if (shown.isEmpty()) setStatus("Tidak ditemukan soal. Arahkan ke halaman soal lalu scan lagi.")
                        else { setStatus("Selesai: ${shown.size} soal dianalisis."); render(shown) }
                    }
                    .onFailure { setStatus("Jawaban AI tidak terbaca. Coba scan ulang.") }
            }.onFailure { setStatus("Error: ${it.message}") }
        }
    }

    private fun fail(msg: String) { busy = false; setStatus(msg) }
    private fun setStatus(s: String) { tvStatus.text = s }

    // ---------------------------------------------------------------- UI
    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun buildUi() {
        val dm = resources.displayMetrics
        bubble = TextView(this).apply {
            text = "AI"; gravity = Gravity.CENTER; textSize = 18f
            setTextColor(C.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(C.BLUE, C.DARK)).apply { shape = GradientDrawable.OVAL }
        }
        bubbleLp = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bubbleLp.x; sy = bubbleLp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) { bubbleLp.x = sx + dx; bubbleLp.y = sy + dy; wm.updateViewLayout(v, bubbleLp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80).withEndAction {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        }.start()
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }

        // ---- panel
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(C.WHITE, 20, C.LINE, 1)
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(tv("BelajarAI", 18f, C.BLUE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(iconBtn("⤢") { toggleExpand() })
        header.addView(iconBtn("—") { hidePanel() })
        header.addView(iconBtn("✕") { stopSelf() })
        panel.addView(header)

        tvChip = tv("", 12f, C.BLUE, true).apply {
            background = bg(C.LIGHT, 14); setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { cycleCount() }
        }
        updateChip()
        panel.addV(tvChip, 6, -2)

        panel.addV(btn("📷  Scan Layar & Jawab") { scan() }, 8)
        tvStatus = tv("Buka halaman soal di aplikasi/website, lalu tekan Scan Layar.", 12f, C.MUTED)
        panel.addV(tvStatus, 6)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(results) }
        panel.addV(scroll, 6, -1, 0)
        (scroll.layoutParams as LinearLayout.LayoutParams).weight = 1f

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        etInput = EditText(this).apply {
            hint = "Perjelas soal / tanya lanjutan…"; textSize = 13f
            background = bg(C.LIGHT, 12); setPadding(dp(12), dp(8), dp(12), dp(8)); maxLines = 3
        }
        row.addView(etInput, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Kirim") {
            val t = etInput.text.toString().trim()
            if (t.isNotEmpty() && !busy) {
                etInput.setText("")
                analyze(lastOcr, t, if (prefs.sendImage) lastBmp else null)
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        panel.addV(row, 8)

        panelLp = WindowManager.LayoutParams(
            dm.widthPixels - dp(24), (dm.heightPixels * 0.55).toInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(12)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(bubble, bubbleLp)
    }

    private fun iconBtn(t: String, onClick: () -> Unit) = tv(t, 18f, C.MUTED, true).apply {
        setPadding(dp(10), dp(6), dp(10), dp(6)); setOnClickListener { onClick() }
    }

    private fun updateChip() {
        val n = if (prefs.processCount == 0) "Semua" else prefs.processCount.toString()
        tvChip.text = "Soal diproses: $n  •  ${prefs.subject}  ⟳"
    }

    private fun cycleCount() {
        val opts = MainActivity.PROCESS
        prefs.processCount = opts[(opts.indexOf(prefs.processCount) + 1) % opts.size]
        updateChip()
    }

    private fun togglePanel() { if (panelShown) hidePanel() else showPanel() }

    private fun showPanel() {
        if (panelShown) return
        updateChip()
        panel.alpha = 0f; panel.translationY = dp(40).toFloat()
        wm.addView(panel, panelLp)
        panel.animate().alpha(1f).translationY(0f).setDuration(220).start()
        panelShown = true
        // pastikan bubble tetap di atas panel
        wm.removeView(bubble); wm.addView(bubble, bubbleLp)
    }

    private fun hidePanel() {
        if (!panelShown) return
        wm.removeView(panel); panelShown = false
    }

    private fun toggleExpand() {
        expanded = !expanded
        updatePanelSize()
    }

    private fun updatePanelSize() {
        if (!uiBuilt) return
        val dm = resources.displayMetrics
        panelLp.width = dm.widthPixels - dp(24)
        panelLp.height = (dm.heightPixels * (if (expanded) 0.92 else 0.55)).toInt()
        if (panelShown) wm.updateViewLayout(panel, panelLp)
    }

    private fun render(items: List<Item>) {
        results.removeAllViews()
        items.forEach { results.addV(itemCard(it), 8) }
        scroll.post { scroll.fullScroll(View.FOCUS_UP) }
    }

    private fun itemCard(it: Item): View {
        val c = card()
        c.addView(tv("Soal ${it.number}", 13f, C.BLUE, true))
        c.addV(tv(it.question, 13f), 4)
        if (it.options.isNotEmpty()) c.addV(tv(it.options.entries.joinToString("\n") { e -> "${e.key}. ${e.value}" }, 12f, C.MUTED), 4)
        if (it.needsClarification) {
            c.addV(tv("⚠ Perlu diperjelas: ${it.clarification}\nKetik penjelasan di kolom bawah lalu tekan Kirim.", 12f, C.ORANGE, true), 6)
        } else {
            c.addV(tv("Jawaban: ${it.answer}", 16f, C.BLUE, true), 6)
            c.addV(tv("Keyakinan AI: ${it.confidence}%", 12f, confColor(it.confidence), true), 4)
            c.addV(confBar(it.confidence), 3)
        }
        if (it.explanation.isNotBlank()) c.addV(tv(it.explanation, 12f), 6)
        return c
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) runCatching { setupCapture() }
        updatePanelSize()
    }

    override fun onDestroy() {
        running = false
        runCatching { if (panelShown) wm.removeView(panel) }
        runCatching { if (uiBuilt) wm.removeView(bubble) }
        latest?.close(); vd?.release(); reader?.close()
        runCatching { projection?.stop() }
        super.onDestroy()
    }
}
