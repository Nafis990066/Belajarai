package com.belajarai.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    companion object {
        val PROCESS = listOf(5, 10, 20, 30, 50, 0)
        val PRACTICE = listOf(5, 10, 20, 30, 50)
        val SCORES = listOf(60, 70, 80, 90, 100)
        val DIFF = listOf("Mudah", "Sedang", "Sulit")
        val SUBJECTS = listOf(
            "Umum (otomatis)", "Matematika", "Fisika", "Kimia", "Biologi", "Sejarah", "Geografi",
            "Ekonomi", "Sosiologi", "Bahasa Indonesia", "Bahasa Inggris", "PPKn", "Informatika"
        )
        private const val REQ_CAPTURE = 1
    }

    private lateinit var prefs: Prefs
    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var spProcess: Spinner
    private lateinit var spPractice: Spinner
    private lateinit var etTarget: EditText
    private lateinit var spScore: Spinner
    private lateinit var spDiff: Spinner
    private lateinit var spSubject: Spinner
    private lateinit var cbImage: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(28)) }
        root.addView(tv("BelajarAI", 28f, C.BLUE, true))
        root.addView(tv("Asisten AI mengambang untuk memahami & berlatih soal.", 13f, C.MUTED))

        // --- aksi utama
        val act = card()
        act.addView(tv("Mulai", 16f, C.TEXT, true))
        act.addV(btn("1. Izinkan tampil di atas aplikasi lain", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, 8)
        act.addV(btn("2. Aktifkan Floating Assistant") { startAssistant() }, 8)
        act.addV(btn("Hentikan Floating Assistant", false) {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP))
        }, 8)
        root.addV(act, 14)

        // --- AI
        val ai = card()
        ai.addView(tv("Koneksi AI", 16f, C.TEXT, true))
        ai.addV(tv("OpenAI API Key", 12f, C.MUTED), 8)
        etKey = field(prefs.apiKey, "sk-proj-…").apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        ai.addV(etKey, 2)
        ai.addV(tv("Model", 12f, C.MUTED), 8)
        etModel = field(prefs.model, "gpt-4.1-mini")
        ai.addV(etModel, 2)
        cbImage = CheckBox(this).apply { text = "Kirim gambar layar ke AI (untuk rumus/diagram)"; isChecked = prefs.sendImage; textSize = 13f }
        ai.addV(cbImage, 8)
        root.addV(ai, 12)

        // --- pengaturan soal
        val st = card()
        st.addView(tv("Pengaturan Soal", 16f, C.TEXT, true))
        st.addV(tv("Jumlah soal yang diproses per scan", 12f, C.MUTED), 8)
        spProcess = spinner(PROCESS.map { if (it == 0) "Semua" else "$it soal" }, PROCESS.indexOf(prefs.processCount).coerceAtLeast(0))
        st.addV(spProcess, 2)
        st.addV(tv("Mata pelajaran", 12f, C.MUTED), 8)
        spSubject = spinner(SUBJECTS, SUBJECTS.indexOf(prefs.subject).coerceAtLeast(0))
        st.addV(spSubject, 2)
        st.addV(tv("Tingkat kesulitan (mode latihan)", 12f, C.MUTED), 8)
        spDiff = spinner(DIFF, DIFF.indexOf(prefs.difficulty).coerceAtLeast(0))
        st.addV(spDiff, 2)
        st.addV(tv("Jumlah soal latihan", 12f, C.MUTED), 8)
        spPractice = spinner(PRACTICE.map { "$it soal" }, PRACTICE.indexOf(prefs.practiceCount).coerceAtLeast(0))
        st.addV(spPractice, 2)
        st.addV(tv("Target jawaban benar (sasaran latihan)", 12f, C.MUTED), 8)
        etTarget = field(prefs.targetCorrect.toString(), "mis. 8").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        st.addV(etTarget, 2)
        st.addV(tv("Target nilai", 12f, C.MUTED), 8)
        spScore = spinner(SCORES.map { "$it" }, SCORES.indexOf(prefs.targetScore).coerceAtLeast(0))
        st.addV(spScore, 2)
        st.addV(tv("Target hanya dipakai sebagai sasaran latihan & evaluasi, bukan untuk mengubah hasil ujian.", 11f, C.MUTED), 8)
        root.addV(st, 12)

        // --- latihan
        val pr = card()
        pr.addView(tv("Mode Latihan", 16f, C.TEXT, true))
        pr.addV(btn("Mulai Simulasi CBT") { save(); startActivity(Intent(this, PracticeActivity::class.java)) }, 8)
        pr.addV(btn("Riwayat Hasil Latihan", false) { startActivity(Intent(this, HistoryActivity::class.java)) }, 8)
        root.addV(pr, 12)

        root.addV(tv(
            "Catatan: gunakan untuk belajar dan latihan. Patuhi aturan sekolah/ujian yang berlaku. " +
                "BelajarAI hanya membaca layar atas izinmu dan tidak membaca layar yang diproteksi aplikasi lain. " +
                "Layar yang kamu scan (teks, dan gambar bila opsi aktif) dikirim ke layanan AI untuk dianalisis.", 11f, C.MUTED), 14)

        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(C.WHITE) })
    }

    private fun field(value: String, hint: String) = EditText(this).apply {
        setText(value); this.hint = hint; textSize = 14f; setSingleLine()
        background = bg(C.LIGHT, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun save() {
        prefs.apiKey = etKey.text.toString().trim()
        prefs.model = etModel.text.toString().trim().ifEmpty { "gpt-4.1-mini" }
        prefs.sendImage = cbImage.isChecked
        prefs.processCount = PROCESS[spProcess.selectedItemPosition]
        prefs.subject = SUBJECTS[spSubject.selectedItemPosition]
        prefs.difficulty = DIFF[spDiff.selectedItemPosition]
        prefs.practiceCount = PRACTICE[spPractice.selectedItemPosition]
        prefs.targetScore = SCORES[spScore.selectedItemPosition]
        prefs.targetCorrect = (etTarget.text.toString().toIntOrNull() ?: 1).coerceIn(1, prefs.practiceCount)
        etTarget.setText(prefs.targetCorrect.toString())
    }

    override fun onPause() { super.onPause(); runCatching { save() } }

    private fun startAssistant() {
        save()
        if (!Settings.canDrawOverlays(this)) { toast("Aktifkan dulu izin 'tampil di atas aplikasi lain' (tombol 1)."); return }
        if (prefs.apiKey.isBlank()) { toast("Isi API key terlebih dahulu."); return }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION") startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, FloatingService::class.java)
                    .putExtra(FloatingService.EXTRA_CODE, resultCode)
                    .putExtra(FloatingService.EXTRA_DATA, data)
                startForegroundService(i)
                toast("Bubble AI aktif. Buka halaman soal lalu tekan bubble.")
                moveTaskToBack(true)
            } else toast("Izin tangkap layar ditolak.")
        }
    }
}
