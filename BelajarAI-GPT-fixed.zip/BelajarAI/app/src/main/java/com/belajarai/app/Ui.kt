package com.belajarai.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

object C {
    val BLUE = Color.parseColor("#1E5EFF")
    val DARK = Color.parseColor("#0B3AA8")
    val LIGHT = Color.parseColor("#EAF1FF")
    val LINE = Color.parseColor("#D5E1FA")
    val TEXT = Color.parseColor("#12203F")
    val MUTED = Color.parseColor("#5B6B8C")
    val GREEN = Color.parseColor("#1B9E5A")
    val ORANGE = Color.parseColor("#E08A00")
    val RED = Color.parseColor("#D64545")
    val WHITE = Color.WHITE
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.bg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.tv(text: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.btn(text: String, primary: Boolean = true, onClick: () -> Unit): Button =
    Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (primary) C.WHITE else C.BLUE)
        background = if (primary) bg(C.BLUE, 12) else bg(C.WHITE, 12, C.BLUE, 1)
        stateListAnimator = null
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = bg(C.WHITE, 14, C.LINE, 1)
    setPadding(dp(14), dp(12), dp(14), dp(12))
}

fun Context.spinner(items: List<String>, selected: Int): Spinner =
    Spinner(this).apply {
        adapter = ArrayAdapter(this@spinner, android.R.layout.simple_spinner_dropdown_item, items)
        setSelection(selected.coerceIn(0, items.size - 1))
        background = bg(C.LIGHT, 10)
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }

fun LinearLayout.addV(v: View, top: Int = 8, w: Int = LinearLayout.LayoutParams.MATCH_PARENT, h: Int = LinearLayout.LayoutParams.WRAP_CONTENT) {
    val p = LinearLayout.LayoutParams(w, h)
    p.topMargin = context.dp(top)
    addView(v, p)
}

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

fun Context.confBar(conf: Int): View = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    val col = if (conf >= 80) C.GREEN else if (conf >= 50) C.ORANGE else C.RED
    addView(View(context).apply { background = bg(col, 4) }, LinearLayout.LayoutParams(0, dp(6), conf.coerceAtLeast(1).toFloat()))
    addView(View(context).apply { background = bg(C.LINE, 4) }, LinearLayout.LayoutParams(0, dp(6), (100 - conf).coerceAtLeast(0).toFloat()))
}

fun confColor(conf: Int) = if (conf >= 80) C.GREEN else if (conf >= 50) C.ORANGE else C.RED

@Suppress("unused")
val centerGravity = Gravity.CENTER
