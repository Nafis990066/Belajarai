# BelajarAI – Floating AI Assistant (Android, Kotlin)

## Cara mendapatkan APK
**A. Android Studio (paling mudah)**
1. Buka Android Studio (Koala/2024.1 atau lebih baru) > Open > pilih folder BelajarAI.
2. Tunggu Gradle sync selesai.
3. Menu Build > Build APK(s). APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

**B. Tanpa Android Studio (GitHub Actions)**
1. Buat repository GitHub, upload seluruh isi folder ini.
2. Buka tab Actions > "Build APK" > Run workflow.
3. Setelah selesai, unduh artifact `BelajarAI-debug-apk`.

## Instalasi di HP
1. Kirim `app-debug.apk` ke HP, buka file tersebut.
2. Izinkan "Instal dari sumber ini" jika diminta.
3. Buka BelajarAI > isi API key OpenAI.
4. Tekan tombol 1 (izin tampil di atas aplikasi lain), lalu tombol 2 (izin tangkap layar > "Mulai sekarang").
5. Buka halaman soal, tekan bubble "AI" > "Scan Layar & Jawab".

Min. Android 8.0 (API 26). Perlu internet untuk AI (OCR berjalan di perangkat).


## Koneksi AI
BelajarAI menggunakan OpenAI Chat Completions API. Model default: `gpt-4.1-mini`. Masukkan OpenAI API Key milikmu pada pengaturan aplikasi. API billing terpisah dari langganan ChatGPT.
