package com.belajarai.app

import android.content.Context

/** Penyimpanan pengaturan lokal (SharedPreferences). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("belajarai", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) { sp.edit().putString("apiKey", v).apply() }
    var model: String
        get() = sp.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) { sp.edit().putString("model", v).apply() }
    /** 0 = semua soal yang terlihat */
    var processCount: Int
        get() = sp.getInt("processCount", 10)
        set(v) { sp.edit().putInt("processCount", v).apply() }
    var practiceCount: Int
        get() = sp.getInt("practiceCount", 10)
        set(v) { sp.edit().putInt("practiceCount", v).apply() }
    var targetCorrect: Int
        get() = sp.getInt("targetCorrect", 8)
        set(v) { sp.edit().putInt("targetCorrect", v).apply() }
    var targetScore: Int
        get() = sp.getInt("targetScore", 80)
        set(v) { sp.edit().putInt("targetScore", v).apply() }
    var difficulty: String
        get() = sp.getString("difficulty", "Sedang") ?: "Sedang"
        set(v) { sp.edit().putString("difficulty", v).apply() }
    var subject: String
        get() = sp.getString("subject", "Umum (otomatis)") ?: "Umum (otomatis)"
        set(v) { sp.edit().putString("subject", v).apply() }
    var sendImage: Boolean
        get() = sp.getBoolean("sendImage", true)
        set(v) { sp.edit().putBoolean("sendImage", v).apply() }
}
