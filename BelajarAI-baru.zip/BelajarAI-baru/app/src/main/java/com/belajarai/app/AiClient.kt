package com.belajarai.app

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/** Klien Anthropic Messages API. Callback selalu dipanggil di main thread. */
object AiClient {
    private const val URL = "https://api.anthropic.com/v1/messages"
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(150, TimeUnit.SECONDS)
        .build()
    private val main = Handler(Looper.getMainLooper())

    fun call(prefs: Prefs, system: String, userText: String, image: Bitmap?, onDone: (Result<String>) -> Unit) {
        val key = prefs.apiKey
        val model = prefs.model
        Thread {
            val r = runCatching { blocking(key, model, system, userText, image) }
            main.post { onDone(r) }
        }.start()
    }

    private fun blocking(key: String, model: String, system: String, userText: String, image: Bitmap?): String {
        require(key.isNotBlank()) { "API key belum diisi. Buka aplikasi BelajarAI > Pengaturan." }
        val content = JSONArray()
        if (image != null) {
            content.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", toBase64(image))
                )
            )
        }
        content.put(JSONObject().put("type", "text").put("text", userText))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 8000)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val req = Request.Builder().url(URL)
            .header("x-api-key", key)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { resp ->
            val s = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(s).getJSONObject("error").getString("message") }.getOrDefault(s.take(200))
                error("API ${resp.code}: $msg")
            }
            val arr = JSONObject(s).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString()
        }
    }

    private fun toBase64(src: Bitmap): String {
        val max = 1600f
        val scale = minOf(1f, max / maxOf(src.width, src.height))
        val b = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun extractJson(text: String): JSONObject {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        require(s >= 0 && e > s) { "Format jawaban AI tidak terbaca." }
        return JSONObject(text.substring(s, e + 1))
    }
}
