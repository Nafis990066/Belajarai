# BelajarAI

Project Android native Kotlin untuk asisten belajar: OCR layar dengan izin MediaProjection, bubble mengambang, bantuan AI, latihan, dan riwayat.

## Build APK paling mudah (tanpa memasang Java/Gradle di HP)
1. Buat repository GitHub baru.
2. Ekstrak ZIP ini, lalu upload **isi folder** `BelajarAI-baru` ke repository (file `.github/workflows/build.yml` harus ikut ter-upload).
3. Buka tab **Actions** di repository.
4. Pilih workflow **Build APK BelajarAI**, lalu tekan **Run workflow**.
5. Setelah selesai, buka hasil run dan unduh artifact `BelajarAI-debug-apk`.

## Build lokal
Memerlukan JDK 17, Android SDK 34, dan koneksi internet untuk mengunduh Gradle 8.7 serta dependensi.
Jalankan `./gradlew assembleDebug` dari folder project.

APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Belum ada APK siap instal di dalam ZIP ini; ZIP berisi source project.
- Fitur tangkap layar hanya bekerja setelah pengguna memberi izin Android. Layar yang dilindungi aplikasi tidak dapat dibaca.
- Fitur AI memerlukan API key yang valid dan koneksi internet. Jangan membagikan API key kepada orang lain.
