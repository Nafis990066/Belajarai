@echo off
set APP_HOME=%~dp0
set GRADLE_VERSION=8.7
set DIST=%USERPROFILE%\.gradle\wrapper\dists\manual\gradle-%GRADLE_VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  echo Jalankan build melalui GitHub Actions atau pasang Gradle 8.7 terlebih dahulu.
  exit /b 1
)
call "%DIST%\bin\gradle.bat" -p "%APP_HOME%" %*
